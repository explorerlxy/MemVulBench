# MemVulBench 可移植阅读包

正文 manuscript.md 与补充材料 supplement.md 使用包内图片相对路径，figures 同时提供 PNG/SVG/PDF。证据 JSON 和 CSV 包含原历史路径，供来源定位，不意味着镜像或 PoC 已随包公开。
